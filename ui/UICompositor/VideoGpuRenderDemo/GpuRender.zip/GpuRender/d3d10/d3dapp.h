#pragma once
#include "common\Inputs.h"

class Direct3DRenderTarget;


class D3D10App
{
public:
	D3D10App();
	~D3D10App();

public:
    void  AddRef();
    void  Release();

	bool  Init();
	void  Destroy();

	UINT  GetDeviceMultisampleQuality() { 
			return m_nMultisampleQuality; }

    bool  IsActiveSwapChain(HWND  hWnd);
    void  SetActiveSwapChain(HWND hWnd);

	void  ApplyTechnique(ID3D10EffectTechnique*  pTech, UI::RECTF*  prcDraw, UI::D3DCOLORVALUE color);
	void  ApplyTechnique(ID3D10EffectTechnique*  pTech, UI::RECTF*  prcDraw, UI::RECTF*  prcTexture, float fAlpha);

public:
    static void Startup();
    static void Shutdown();
    static D3D10App*  Get();

private:
    long  m_lRef;
    static D3D10App* s_pApp;

public:
	ID3D10Device*    m_pDevice;
	IDXGIFactory*    m_pDXGIFactory;
    ID3DX10Sprite*   m_pSprite10;

    //  ��ǰdevice�б�ѡ���rendertarget��������
    HWND  m_hActiveWnd;  	

private:
	UINT  m_nMultisampleQuality;
};

