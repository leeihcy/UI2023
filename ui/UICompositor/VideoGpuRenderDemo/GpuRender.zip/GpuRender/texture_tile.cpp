#include "stdafx.h"
#include "texture_tile.h"
#include "d3d10\d3dapp.h"
#include <atlimage.h>
#include "d3d10\common\Effects.h"

TextureTile::TextureTile()
{
	m_width = 0;
	m_height = 0;
	m_xIndex = 0;
	m_yIndex = 0;

	m_pTextureBuffer = nullptr;
	m_pShaderResourceView = nullptr;
}
TextureTile::~TextureTile()
{
    SAFE_RELEASE(m_pTextureBuffer);
    SAFE_RELEASE(m_pShaderResourceView);
}

// TODO: ������CPU���ĵ㡣
// 1. ������Ҫ��for/forѭ������Ϊʹ��memcpy����Ӧ��������ʽ��
// 2. dx10Ŀǰ����֧��24λRGBͼ���ʽ��
void TextureTile::Upload(RECT& rcSrc, UploadGpuBitmapInfo& source)
{
    if (!m_pTextureBuffer)
    {
        create();
    }

    D3D10_MAPPED_TEXTURE2D mappedTexture;
    UINT  nSub = D3D10CalcSubresource(0, 0, 1);

    // Create��ʱ��û�з����Դ棬��Mapʱ�����Դ�
    HRESULT hr = m_pTextureBuffer->Map(nSub, D3D10_MAP_WRITE_DISCARD, 0, &mappedTexture);
    if (FAILED(hr))
        return;

    D3D10_TEXTURE2D_DESC desc;     
    m_pTextureBuffer->GetDesc( &desc );     

    // �����������û�������Tile������Ҫ���հ״���0���Է���һ�ε������ݸ���
   int w = rcSrc.right - rcSrc.left;
   int h = rcSrc.bottom - rcSrc.top;
   if (w != TILE_SIZE || h != TILE_SIZE)
    {
        byte*  pTexels = (byte*)mappedTexture.pData;
        for (int y = 0; y < TILE_SIZE; y++)
        {
            memset(pTexels, 0, 4 * TILE_SIZE);
            pTexels += mappedTexture.RowPitch;
        }
    } 

    BYTE*  pSrcBits = (BYTE*)source.pFirstLineBits;
    byte*  pTexels = (byte*)mappedTexture.pData;    

    pSrcBits += rcSrc.top * source.pitch;

    if (source.hasAlphaChannel)
    {
		if (source.bpp == 32)
		{
			for (int row = rcSrc.top; row < rcSrc.bottom; row++)  
			{       
				int dstcol = 0;
				for (int col = rcSrc.left; col < rcSrc.right; col++, dstcol++)  
				{      
					int dst = dstcol*4;
					int src = col*4;
					pTexels[dstcol + 0] = pSrcBits[src + 2]; // Red       
					pTexels[dstcol + 1] = pSrcBits[src + 1]; // Green     
					pTexels[dstcol + 2] = pSrcBits[src + 0]; // Blue        
					pTexels[dstcol + 3] = pSrcBits[src + 3]; // Alpha   
				}    

				pSrcBits += source.pitch;
				pTexels += mappedTexture.RowPitch;
			}  
		}
		else if (source.bpp == 24)
		{
			for (int row = rcSrc.top; row < rcSrc.bottom; row++)  
			{       
				int dstcol = 0;
				for (int col = rcSrc.left; col < rcSrc.right; col++, dstcol++)  
				{      
					int dst = dstcol*4;
					int src = col*3;
					pTexels[dst + 0] = pSrcBits[src + 2]; // Red       
					pTexels[dst + 1] = pSrcBits[src + 1]; // Green     
					pTexels[dst + 2] = pSrcBits[src + 0]; // Blue        
					pTexels[dst + 3] = 255; // Alpha   
				}    

				pSrcBits += source.pitch;
				pTexels += mappedTexture.RowPitch;
			}  
		}
    }
    else
    {
		if (source.bpp == 32)
		{
			for (int row = rcSrc.top; row < rcSrc.bottom; row++)  
			{       
				int dstcol = 0;
				for (int col = rcSrc.left; col < rcSrc.right; col++, dstcol++)  
				{        
					int dst = dstcol*4;
					int src = col*4;

					pTexels[dst + 0] = pSrcBits[src + 2]; // Red       
					pTexels[dst + 1] = pSrcBits[src + 1]; // Green     
					pTexels[dst + 2] = pSrcBits[src + 0]; // Blue        
					pTexels[dst + 3] = 255;
				}    

				pSrcBits += source.pitch;
				pTexels += mappedTexture.RowPitch;
			}  
		}
		else if (source.bpp == 24)
		{
			for (int row = rcSrc.top; row < rcSrc.bottom; row++)  
			{       
				int dstcol = 0;
				for (int col = rcSrc.left; col < rcSrc.right; col++, dstcol++)  
				{        
					int dst = dstcol*4;
					int src = col*3;

					pTexels[dst + 0] = pSrcBits[src + 2]; // Red       
					pTexels[dst + 1] = pSrcBits[src + 1]; // Green     
					pTexels[dst + 2] = pSrcBits[src + 0]; // Blue        
					pTexels[dst + 3] = 255;
				}    

				pSrcBits += source.pitch;
				pTexels += mappedTexture.RowPitch;
			}  
		}
    }

    m_pTextureBuffer->Unmap(nSub);



#ifdef _DEBUG
    static bool bDebug = false;
    if (bDebug)
    {
        static int i = 0; 
        i++;
        TCHAR szTest[256];
        _stprintf(szTest, TEXT("c:\\AAA\\%d.dds"),i);
        D3DX10SaveTextureToFile(m_pTextureBuffer, D3DX10_IFF_DDS, szTest);

        CImage image;
        image.Attach(source.hBitmap);

        _stprintf(szTest, TEXT("c:\\AAA\\%d_(%d_%d_%d_%d).png"),i,
                rcSrc.left,rcSrc.top,rcSrc.right,rcSrc.bottom);            
        image.Save(szTest, Gdiplus::ImageFormatPNG);
        image.Detach();
    }
#endif
}


bool TextureTile::create()
{
    if (m_pTextureBuffer || m_pShaderResourceView)
        return false;

    if (!D3D10App::Get()->m_pDevice)
        return false;

    D3D10_TEXTURE2D_DESC textureDesc;
    ZeroMemory(&textureDesc, sizeof(textureDesc));

    textureDesc.Width = TILE_SIZE;
    textureDesc.Height = TILE_SIZE;
    textureDesc.MipLevels = 1;
    textureDesc.ArraySize = 1;
    textureDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM; 
    textureDesc.SampleDesc.Count = 1;
    textureDesc.SampleDesc.Quality = 0;
    textureDesc.BindFlags = D3D10_BIND_SHADER_RESOURCE;
    textureDesc.Usage = D3D10_USAGE_DYNAMIC;
    textureDesc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
    textureDesc.MiscFlags = 0;

    HRESULT hr = D3D10App::Get()->m_pDevice->CreateTexture2D(&textureDesc, 
        nullptr, &m_pTextureBuffer);
    if (FAILED(hr))
        return false;

    D3D10_SHADER_RESOURCE_VIEW_DESC shaderResourceViewDesc;
    shaderResourceViewDesc.Format = textureDesc.Format;
    shaderResourceViewDesc.ViewDimension = D3D10_SRV_DIMENSION_TEXTURE2D;
    shaderResourceViewDesc.Texture2D.MostDetailedMip = 0;
    shaderResourceViewDesc.Texture2D.MipLevels = 1;

    hr = D3D10App::Get()->m_pDevice->CreateShaderResourceView(
            m_pTextureBuffer, 
            &shaderResourceViewDesc, 
            &m_pShaderResourceView);
    if (FAILED(hr))
    {
        SAFE_RELEASE(m_pTextureBuffer);
        return false;
    }

    return true;
}


void  TextureTile::SetIndex(int xIndex, int yIndex)
{
    m_xIndex = xIndex;
    m_yIndex = yIndex;
}

// vertexStartIndex:
// �����ÿ��tile��������һ��vertex buffer����ᵼ��ÿ�λ���֮ǰ��Ҫ�л���ǰvertex buffer��
// ʹ����Ⱦ���ܺܲ�������������������������п��vb��������layer�����У�Ȼ��ͨ������������
void  TextureTile::Compositor(
	long vertexStartIndex)
{
	if (!m_pShaderResourceView)
		return ;

	Effects::m_pFxTexture10->SetResource(m_pShaderResourceView);

	ID3D10EffectTechnique* pTech = Effects::m_pTechDrawTexture;

	D3D10_TECHNIQUE_DESC techDesc;
	pTech->GetDesc(&techDesc);

	for (UINT p = 0; p < techDesc.Passes; ++p)
	{
		pTech->GetPassByIndex(p)->Apply(0);
		D3D10App::Get()->m_pDevice->Draw(4, vertexStartIndex);
	}
}


