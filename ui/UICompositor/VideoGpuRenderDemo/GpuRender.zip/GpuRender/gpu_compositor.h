#pragma once
#include "texture_tile.h"
#include "gpu_layer.h"

// һ�����ڵ�Gpu�ϳ���
namespace UI
{
class GpuRenderLayer;
class GpuComposition : public IGpuRender
{
public:
	GpuComposition(HWND hWnd);
	~GpuComposition();

	virtual void  Release() override {
		delete this;
	}

	virtual void  Render() override;
	virtual void  SetBigRenderParam(float scale, int x, int y) override;
	virtual void  SetSmallRenderParam(float scale, int x, int y) override;
	virtual void  UploadBig(UploadGpuBitmapInfo&) override;
	virtual void  UploadSmall(UploadGpuBitmapInfo&) override;

	bool  BeginCommit();
	void  EndCommit();

    void  Resize(UINT nWidth, UINT nHeight);
    SIZE  GetSize() {
            return m_sizeBackBuffer; }

    void  ClearStencil();

protected:
    void  CreateSwapChain();
    void  ReCreateRenderTargetView();
	void  ReCreateStencilView();

public:
	D3DXMATRIX  m_matrixView;   // ����ͶӰ����

private:
	GpuRenderLayer*  m_pRootTexture;
	HWND  m_hWnd;

    IDXGISwapChain*  m_pSwapChain;
    ID3D10RenderTargetView*  m_pRenderTargetView;
	
	ID3D10Texture2D*  m_pDepthStencilBuffer;
	ID3D10DepthStencilView*  m_pDepthStencilView;

    SIZE   m_sizeBackBuffer;

	//////////////////////////////////////////////////////////////////////////
	//
	UI::GpuRenderLayer  m_BigView;
	UI::GpuRenderLayer  m_SmallView;
	//
	//////////////////////////////////////////////////////////////////////////
};
}