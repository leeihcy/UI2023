#include "stdafx.h"
#include "gpu_compositor.h"



extern "C" 
{
	GPURENDER_API IGpuRender* CreateGpuRender(HWND hWnd)
	{
		UI::GpuComposition* p = new UI::GpuComposition(hWnd);
		return p;
	}
}
