#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files:


#pragma warning(disable:4996)
// warning C4201: ʹ���˷Ǳ�׼��չ : �����ƵĽṹ/����
#pragma warning(disable:4201)
// warning C4100: ��lpReserved��: δ���õ��β�
#pragma warning(disable:4100)
// warning C4481: ʹ���˷Ǳ�׼��չ: ����д˵������override��
#pragma warning(disable:4481)

#pragma warning(disable:4838)

#include <windows.h>
#include <tchar.h>
#include <atlbase.h>
#include <atlstr.h>
#include <list>
using namespace std;

#include "common\common_def.h"
#include "include\GpuRender_inc.h"

#include "UI\UISDK\Inc\inc.h"
#pragma comment(lib,"uisdk.lib")

#include "ui\common\math\rect.h"
#include "ui\common\math\color.h"


#include "include\framework_inc.h"
#pragma comment(lib, "framework.lib")

//#include <D3D10_1.h> 
#include <d3dx10.h>

#pragma comment(lib, "d3d10.lib")
//#ifdef _DEBUG
//#pragma comment(lib, "d3dx10d.lib") 
//#else
#pragma comment(lib, "d3dx10.lib")
//#endif
//#pragma comment(lib, "D3D10_1.lib")

#ifdef _DEBUG
#define  ASSERTEXEX(x)  if (!(x)) { DebugBreak(); }
#else
#define  ASSERTEXEX(x)  
#endif
namespace UI
{
	typedef struct _D3DCOLORVALUE {
		float r;
		float g;
		float b;
		float a;
	} D3DCOLORVALUE;
}


using namespace Lenovo;
extern HMODULE g_hInstance;