#include "stdafx.h"
#include "gpu_layer.h"
#include "texture_tile.h"
#include "gpu_compositor.h"
#include "D3D10/d3dapp.h"
#include "d3d10\common/RenderStates.h"
#include "d3d10\common/Effects.h"

using namespace UI;


GpuRenderLayer::GpuRenderLayer()
{
	m_pVertexBuffer = nullptr;
	m_pParent = m_pChild = m_pNext = nullptr;
	m_size.cx = m_size.cy = 0;

    m_pCompositor = nullptr;
}

GpuRenderLayer::~GpuRenderLayer()
{
	Destroy();
}
void  GpuRenderLayer::Destroy()
{
    SAFE_RELEASE(m_pVertexBuffer);

	GpuRenderLayer* pChild = m_pChild;
	while (pChild)
	{
		GpuRenderLayer* pTemp = pChild->m_pNext;
		SAFE_DELETE(pChild);
		pChild = pTemp;
	}
	m_pChild = m_pNext = nullptr;
	m_pParent = nullptr;

    auto iter = m_listTile.begin();
    for (; iter != m_listTile.end(); ++iter)
    {
        delete *iter;
    }
    m_listTile.clear();
}

// IGpuRenderLayer*  GpuRenderLayer::GetIGpuLayerTexture()
// {
//     return static_cast<IGpuRenderLayer*>(this);
// }

void  GpuRenderLayer::Release()
{
    delete this;
}

void  GpuRenderLayer::SetHardwareComposition(GpuComposition* p)
{
    m_pCompositor = p;
}

void  GpuRenderLayer::UploadHBITMAP(UploadGpuBitmapInfo& info)
{
    if (!info.hBitmap)
        return;

	UINT nCount = info.nCount;
	RECT* prcArray = info.prcArray;

    RECT  rcFull = {0, 0, info.width, info.height};
    if (0 == info.nCount || nullptr == info.prcArray)
    {
		nCount = 1;
		prcArray = &rcFull;
    }

    for (UINT i = 0; i < nCount; i++)
    {
        RECT  rc = rcFull;
        if (prcArray)
            IntersectRect(&rc, &rc, &prcArray[i]);

        upload_bitmap_rect(rc, info);
    }
}

void  GpuRenderLayer::upload_bitmap_rect(RECT& rc, UploadGpuBitmapInfo& source)
{
    // ������Ӱ��� tile 
    // -1: ����(0~128)����Ӱ��ľ���һ������0����Ӱ������1(128/128=1)
    int xIndexFrom = rc.left / TILE_SIZE;
    int xIndexTo = (rc.right-1) / TILE_SIZE;
    int yIndexFrom = rc.top / TILE_SIZE;
    int yIndexTo = (rc.bottom-1) / TILE_SIZE;

    RECT rcSrc;
    for (int y = yIndexFrom; y <= yIndexTo; y++)
    {
        for (int x = xIndexFrom; x <= xIndexTo; x++)
        {
            rcSrc.left = x*TILE_SIZE;
            rcSrc.top = y*TILE_SIZE;
            rcSrc.right = rcSrc.left + TILE_SIZE;
            rcSrc.bottom = rcSrc.top + TILE_SIZE;

            // ����������С������ֱ�Ӻ��ԡ���һ���������λ���Ҳ�͵ײ���
            // ��Щ�ֿ�
            if (rcSrc.right > m_size.cx)
                rcSrc.right = m_size.cx;
            if (rcSrc.bottom > m_size.cy)
                rcSrc.bottom = m_size.cy;

            m_arrayTile[y][x]->Upload(rcSrc, source);

        }
    }
}

//
//  ע������ÿ���ֿ鶼���õ��ǹ̶���С��λ�����Ҳ�͵ײ��ķֿ�Ҳ��һ����
//      ��С��������ȥƥ����ʵ�Ĵ��ڴ�С��
//      �������ĺô��Ǵ��ڸı��Сʱ����Ƶ����ɾ�������·ֿ顣
//
void  GpuRenderLayer::create_tile(ULONG row, ULONG col)
{
    ASSERTEX (row > 0 && col > 0);

    if (m_arrayTile.GetCol() == col && 
        m_arrayTile.GetRow() == row)
    {
        return;
    }

    int nCountNew = row * col;
    int nCountNow = m_arrayTile.GetCol() * m_arrayTile.GetRow();

    // ��������
    long lDiff = nCountNew - nCountNow;
    if (lDiff > 0)
    {
        // ����
        for (int i = 0; i < lDiff; i++)
        {
            m_listTile.push_back(new TextureTile);
        }
    }
    else if (lDiff < 0)
    {
        // ɾ��
        list<TextureTile*>::iterator iter = m_listTile.begin();
        for (int i = 0; i < lDiff; i++)
        {
            delete *iter;
            iter = m_listTile.erase(iter);
        }
    }

    // ����λ�õ���
    m_arrayTile.Create(row, col);

    list<TextureTile*>::iterator iter = m_listTile.begin();
    for (ULONG y = 0; y < row; y++)
    {
        for (ULONG x = 0; x < col; x++)
        {
            m_arrayTile[y][x] = (*iter);
            (*iter)->SetIndex(x, y);
            ++iter;
        }
    }
}

void  GpuRenderLayer::Resize(UINT nWidth, UINT nHeight)
{
    if (m_size.cx == (int)nWidth && 
        m_size.cy == (int)nHeight)
    {
        return;
    }

    int col = (int)ceil((float)nWidth / TILE_SIZE);
    int row = (int)ceil((float)nHeight / TILE_SIZE);

    create_tile(row, col);

    m_size.cx = nWidth;
    m_size.cy = nHeight;

    // ����vbo
    SAFE_RELEASE(m_pVertexBuffer);
    
    D3D10_BUFFER_DESC BufDesc;
    BufDesc.ByteWidth = sizeof(DXUT_SCREEN_VERTEX_10) * 4 * row * col;
    BufDesc.Usage = D3D10_USAGE_DYNAMIC;
    BufDesc.BindFlags = D3D10_BIND_VERTEX_BUFFER;
    BufDesc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
    BufDesc.MiscFlags = 0;

    D3D10App::Get()->m_pDevice->CreateBuffer(&BufDesc,
        nullptr,
        &m_pVertexBuffer);

    // �ϴ�һ��������Ҫ�õĶ������ݡ�������
    
    DXUT_SCREEN_VERTEX_10* pVB = nullptr;
    if (SUCCEEDED(m_pVertexBuffer->Map(D3D10_MAP_WRITE_DISCARD, 0, (LPVOID*)&pVB)))
    {
        for (int y = 0; y < row; ++y)
        {
            for (int x = 0; x < col; ++x)
            {
                int x1 = x + 1;
                int y1 = y + 1;

                UI::D3DCOLORVALUE color = { 1, 1, 1, 1 };
                DXUT_SCREEN_VERTEX_10 vertices[4] =
                {
                    { (float)TILE_SIZE*x,  (float)TILE_SIZE*y,  0.f, color, 0, 0 },
                    { (float)TILE_SIZE*x1, (float)TILE_SIZE*y,  0.f, color, 1, 0 },
                    { (float)TILE_SIZE*x,  (float)TILE_SIZE*y1, 0.f, color, 0, 1 },
                    { (float)TILE_SIZE*x1, (float)TILE_SIZE*y1, 0.f, color, 1, 1 },
                };

                CopyMemory(pVB, vertices, sizeof(DXUT_SCREEN_VERTEX_10) * 4);
                pVB += 4;
            }
        }
       
        m_pVertexBuffer->Unmap();
    }
}

void  GpuRenderLayer::CalcDrawDestRect(__in RECTF* prc, __out RECTF* prcfOut)
{
    prcfOut->left = prc->left * 2.0f / m_size.cx - 1.0f;
    prcfOut->right = prc->right * 2.0f / m_size.cx - 1.0f;
    prcfOut->top = 1.0f - prc->top * 2.0f / m_size.cy;
    prcfOut->bottom = 1.0f - prc->bottom * 2.0f / m_size.cy;
}
void  GpuRenderLayer::CalcDrawDestRect(int xDest, int yDest, UINT wDest, UINT hDest, __out RECTF* prcfOut)
{
    prcfOut->left = xDest * 2.0f / m_size.cx - 1.0f;
    prcfOut->right = (xDest+wDest) * 2.0f / m_size.cx - 1.0f;
    prcfOut->top = 1.0f - yDest * 2.0f / m_size.cy;
    prcfOut->bottom = 1.0f - (yDest+hDest) * 2.0f / m_size.cy;
}
void  GpuRenderLayer::CalcDrawDestRect(float xDest, float yDest, float wDest, float hDest, __out RECTF* prcfOut)
{
    prcfOut->left = xDest * 2.0f / m_size.cx - 1.0f;
    prcfOut->right = (xDest+wDest) * 2.0f / m_size.cx - 1.0f;
    prcfOut->top = 1.0f - yDest * 2.0f / m_size.cy;
    prcfOut->bottom = 1.0f - (yDest+hDest) * 2.0f / m_size.cy;
}

void  GpuRenderLayer::SetRenderParam(float scale, int xDest, int yDest)
{
	// �����ţ���ƽ��
	D3DXMATRIX matrixScale;
	::D3DXMatrixScaling(&matrixScale, scale, scale, 1);
	D3DXMATRIX matrixTranslate;
	::D3DXMatrixTranslation(&matrixTranslate, (float)xDest, (float)yDest, 0);

	::D3DXMatrixMultiply(&m_matrixWorld, &matrixScale, &matrixTranslate);
}

void  GpuRenderLayer::Compositor()
{
    if (0 == m_size.cx || 0 == m_size.cy)
        return;

    ID3D10Device*  pDevice = D3D10App::Get()->m_pDevice;

	// �Ȳ����Ǽ���
//     {
//         D3D10_RECT rects[1];
//         memcpy(rects, &pContext->m_rcClip, sizeof(RECT));
//         pDevice->RSSetScissorRects(1, rects);
//     }
	
    UINT stride = sizeof(DXUT_SCREEN_VERTEX_10);
    UINT offset = 0;
    D3D10App::Get()->m_pDevice->IASetVertexBuffers(0, 1,
        &m_pVertexBuffer,
        &stride, &offset);

	
	// ͨ��scale��������ž��󣬲����µ�fx����
	D3DXMATRIX mat;
	::D3DXMatrixMultiply(&mat, &m_matrixWorld, &m_pCompositor->m_matrixView);
	Effects::m_pFxMatrix->SetMatrix((float*)&mat); 

	// 	if (pContext->m_fAlpha != 1.0f)
	// 		Effects::m_pFxAlpha->SetFloat(pContext->m_fAlpha);

	// ������
	ULONG row = m_arrayTile.GetRow();
	ULONG col = m_arrayTile.GetCol();

	long xOffset = 0;
	long yOffset = 0;
    for (ULONG y = 0; y < row; y++)
    {
        //yOffset = y * TILE_SIZE;
        for (ULONG x = 0; x < col; x++)
        {
            //xOffset = x * TILE_SIZE;
            
            m_arrayTile[y][x]->Compositor((y*col + x) * 4);
        }
    }

	// ��ԭ����

	// 	if (pContext->m_fAlpha != 1.0f)
	// 		Effects::m_pFxAlpha->SetFloat(1.0f);
}

